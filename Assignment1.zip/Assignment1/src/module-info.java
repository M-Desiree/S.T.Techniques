/**
 * 
 */
/**
 * 
 */
module Assignment1 {
	requires java.sql;
	requires org.junit.jupiter.api;
}